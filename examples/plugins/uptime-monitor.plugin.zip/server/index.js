(() => {
  var __defProp = Object.defineProperty;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // examples/plugins/uptime-monitor/server/index.ts
  var exports_server = {};
  __export(exports_server, {
    default: () => server_default
  });
  var failureCounters = new Map;
  var mod = {
    install(api) {
      api.plugin.log("Uptime Monitor installed — open the Uptime tab in the admin to configure URLs.");
    },
    async activate(api) {
      api.plugin.log("Uptime Monitor activating");
      api.cms.routes.get("/status", "plugins.manage", async () => {
        const configuredUrls = parseUrls(api.cms.settings.get("urls") ?? "");
        const all = await api.cms.storage.collection("checks").list();
        const byUrl = new Map;
        for (const row of all) {
          const data = row.data;
          const list = byUrl.get(data.url) ?? [];
          list.push(data);
          byUrl.set(data.url, list);
        }
        const cutoff = Date.now() - 24 * 60 * 60 * 1000;
        const summary = configuredUrls.map((url) => {
          const rows = byUrl.get(url) ?? [];
          const sorted = rows.slice().sort((a, b) => new Date(b["checked-at"]).getTime() - new Date(a["checked-at"]).getTime());
          const recent = sorted.filter((r) => new Date(r["checked-at"]).getTime() >= cutoff);
          const okCount = recent.filter((r) => r.ok).length;
          const failCount = recent.length - okCount;
          const avgLatency = recent.length ? Math.round(recent.reduce((acc, r) => acc + r["latency-ms"], 0) / recent.length) : 0;
          return {
            url,
            last: sorted[0] ?? null,
            last24h: {
              checks: recent.length,
              ok: okCount,
              failed: failCount,
              uptime_pct: recent.length ? Math.round(okCount / recent.length * 100) : null,
              avg_latency_ms: avgLatency
            }
          };
        });
        return {
          ok: true,
          plugin: api.plugin.id,
          urls: summary,
          generated_at: new Date().toISOString()
        };
      });
      api.cms.hooks.on("uptime.failure", async (payload) => {
        api.plugin.log("FAILURE alert:", JSON.stringify(payload));
      });
      api.cms.hooks.on("uptime.daily-summary", async (payload) => {
        api.plugin.log("Daily summary:", JSON.stringify(payload));
      });
      api.cms.schedule.every(5, "check-urls", async () => {
        const urls = parseUrls(api.cms.settings.get("urls") ?? "");
        const timeoutMs = Number(api.cms.settings.get("timeout_ms") ?? 5000);
        const threshold = Number(api.cms.settings.get("failure_threshold") ?? 3);
        if (urls.length === 0) {
          api.plugin.log("No URLs configured — open Settings to add some.");
          return;
        }
        api.plugin.log(`Checking ${urls.length} URL(s)`);
        for (const url of urls) {
          const result = await checkOnce(url, timeoutMs);
          await api.cms.storage.collection("checks").create({
            url: result.url,
            "status-code": result["status-code"],
            "latency-ms": result["latency-ms"],
            ok: result.ok,
            error: result.error,
            "checked-at": result["checked-at"]
          });
          if (result.ok) {
            failureCounters.set(url, 0);
          } else {
            const next = (failureCounters.get(url) ?? 0) + 1;
            failureCounters.set(url, next);
            if (next === threshold) {
              await api.cms.hooks.emit("uptime.failure", {
                url,
                consecutive_failures: next,
                last_error: result.error,
                checked_at: result["checked-at"]
              });
            }
          }
        }
      });
      api.cms.schedule.register({
        id: "daily-summary",
        cadence: { interval: "daily", at: "00:05" },
        maxDurationMs: 30000,
        handler: async () => {
          const cutoff = Date.now() - 24 * 60 * 60 * 1000;
          const all = await api.cms.storage.collection("checks").list();
          const recent = all.filter((r) => new Date(r.data["checked-at"]).getTime() >= cutoff);
          const total = recent.length;
          const ok = recent.filter((r) => r.data.ok).length;
          await api.cms.hooks.emit("uptime.daily-summary", {
            total_checks: total,
            ok_checks: ok,
            failed_checks: total - ok,
            uptime_pct: total ? Math.round(ok / total * 100) : null,
            window_start: new Date(cutoff).toISOString(),
            window_end: new Date().toISOString()
          });
        }
      });
      api.plugin.log("Uptime Monitor activated — schedules registered, route mounted.");
    },
    deactivate(api) {
      api.plugin.log("Uptime Monitor deactivated.");
    },
    uninstall(api) {
      api.plugin.log("Uptime Monitor uninstalled.");
    }
  };
  var server_default = mod;
  function parseUrls(raw) {
    return raw.split(/[,\n]/).map((s) => s.trim()).filter((s) => /^https?:\/\//.test(s));
  }
  async function checkOnce(url, timeoutMs) {
    const started = Date.now();
    const checkedAt = new Date().toISOString();
    try {
      const safeTimeout = Math.max(500, Math.min(timeoutMs, 30000));
      const result = await fetch(url, {
        method: "GET",
        signal: AbortSignal.timeout(safeTimeout)
      });
      const elapsed = Date.now() - started;
      return {
        url,
        "status-code": result.status,
        "latency-ms": elapsed,
        ok: result.ok,
        error: result.ok ? null : `HTTP ${result.status}`,
        "checked-at": checkedAt
      };
    } catch (err) {
      const elapsed = Date.now() - started;
      return {
        url,
        "status-code": null,
        "latency-ms": elapsed,
        ok: false,
        error: err instanceof Error ? err.message : String(err),
        "checked-at": checkedAt
      };
    }
  }

  // examples/plugins/uptime-monitor/server/__sandbox-facade-1779179936360.ts
  var __default = exports_server && server_default;
  var __isPluginModule = (v) => v && typeof v === "object" && (typeof v.install === "function" || typeof v.activate === "function" || typeof v.deactivate === "function" || typeof v.uninstall === "function" || typeof v.migrate === "function");
  globalThis.__plugin_exports = __isPluginModule(__default) ? __default : exports_server;
})();
